<div class="about-container">
        <!--img-->
    <img src="pic1.jpg"/>
        <!--about-me-text-->
    <div class="about-text">
        <p>About Us</p>
        <p>South African Electrical Company</p>
        <p>Tjeya is a South African Electrical Company which Guarantee The Highest Quality Workmanship For All Your Electrical Needs. Contact Us! Offering A Range Of Electrical Services For Residential & Commercial Needs. Licensed Team Of Experts. Trained Technicians. HVAC Specialists.
        Relied upon for professional cost-effective electrical services by. Developers, Engineers, Contractors and Homeowners for the past 22 years.</p>
        <p>We're the most highly-trained, industry-certified electricians with years of experience working for both industrial and commercial clients. </p>
        <button><a href="about.html">ABOUT US</a></button>
        <button><a href="about.html">CONTACT</a></button>
    </div>
</div>