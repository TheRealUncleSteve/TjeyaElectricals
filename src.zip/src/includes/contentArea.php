<div class="text-container">
<p>Hello,</p>
<p>Welcome</p>
<p>We're the most highly-trained, <br>industry-certified electricians with <br>years of experience working for both<br> industrial and commercial clients</p>
<button class="hire-btn">WHY US ?</button>
<button class="down-cv">Our Services</button>
</div>

<!--The floating card that offers a summary of the business profile-->
<?php include "includes/fltngCrd.php" ;?>
<?php include "includes/srvcs.php" ;?>
<?php include "includes/connect.php" ;?>