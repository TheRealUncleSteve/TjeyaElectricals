<div class="services ">
    <div class="services-text ">
        <p>ABOUT US</p>
        <p>Quality Service</p>
        <p>We Guarantee The Highest Quality Workmanship For All Your Electrical Needs. Contact Us! Offering A Range Of Electrical Services For Residential & Commercial Needs. Licensed Team Of Experts. Trained Technicians. HVAC Specialists.
            Relied upon for professional cost-effective electrical services by. Developers, Engineers, Contractors and Homeowners for the past 22 years.</p>
    </div>

    <div class="box-container">
        <div class="box-1">
            <span>1</span>
            <p class="heading">Prod/Service</p>
            <p class="details">Electrical construction is a highly-specialized, highly-skilled discipline that is essential for local municipalities, industrial settings, and just about any infrastructure you can think of.</p>
            <button>Read More</button>
        </div>

        <div class="box-2">
            <span>2</span>
            <p class="heading">Prod/Service</p>
            <p class="details">Electrical construction is a highly-specialized, highly-skilled discipline that is essential for local municipalities, industrial settings, and just about any infrastructure you can think of.</p>
            <button>Read More</button>
        </div>

        <div class="box-3">
            <span>3</span>
            <p class="heading">Prod/Service</p>
            <p class="details">Electrical construction is a highly-specialized, highly-skilled discipline that is essential for local municipalities, industrial settings, and just about any infrastructure you can think of.</p>
            <button>Read More</button>
        </div>
    </div>
</div>