<div class="contact-me">
<p>NEED OUR ASSISTANCE?</p>
<button><a href="contact.html">REQUEST A QUOTE</a></button>
</div>