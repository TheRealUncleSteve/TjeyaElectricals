<a href="#" class="logo" id="lg"><span id="lg1">TJEYA</span> electricals</a>

<div class="hamburger">
    <div class="line"></div>
    <div class="line"></div>
    <div class="line"></div>
</div>

<ul class="nav_links">
<li><a href="#" class="active">Home</a></li>
<li><a href="#">About</a></li>
<li><a href="contact.html">Contact us</a></li>
<li><a href="#">Our Team</a></li>
</ul>
