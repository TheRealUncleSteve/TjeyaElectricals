    <footer>
        <p>Connect with Us</p>
        <p>We are continuously working hard to improve customer service and create a magical experience for our customers by providing superior and quality services</p>

        <div class="social-icons">
            <a href="#"><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
            <a href="#"><i class="fab fa-youtube"></i></a>
        </div>
        <p class="copyright"><?php echo ("Copyright &copy; Project compiled by Muzikayise Nkosi & Nelisiwe Mathebula");?></p>
    </footer>
</section>
<!--javaScript links-->
<script type="text/javascript" src="Javascript/stckyHeader.js"></script>
<script type="text/javascript" src="Javascript/responsivenav.js"></script>
</body>
</html>