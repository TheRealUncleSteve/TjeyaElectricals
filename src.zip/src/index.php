<?php include "includes/header.php";?>

<section class="container">
    <section class="nvSctn">
        <nav id="nv">
            <?php include "includes/navigation.php";?>
        </nav>
    </section>
    <section class="contentArea">
        <!--This is the content of the home page-->
        <?php include "includes/contentArea.php";?>
    </section>




<?php include "includes/footer.php";?>
